<?php
/* Include all individual CPT. */
$prefix_cpt = "cpt_";

/* Treatments */
require_once( $prefix_cpt . "treatments.php" );

?>