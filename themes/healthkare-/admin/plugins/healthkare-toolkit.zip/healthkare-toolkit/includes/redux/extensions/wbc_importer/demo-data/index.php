<?php
// Silence is golden